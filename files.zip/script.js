/* ==========================================================================
   BNIMS - Bangladesh National ID Management System
   Main JavaScript
   ========================================================================== */

document.addEventListener('DOMContentLoaded', function () {

  /* ---------------------------------------------------------------------
     PAGE DETECTION
  --------------------------------------------------------------------- */
  const isLoginPage = document.body.classList.contains('login-body');
  const isDashboardPage = document.body.classList.contains('dashboard-body');

  /* =======================================================================
     LOGIN PAGE LOGIC
  ======================================================================= */
  if (isLoginPage) {

    /* ---- Floating particles background ---- */
    const particleContainer = document.getElementById('particles');
    if (particleContainer) {
      const particleCount = 22;
      for (let i = 0; i < particleCount; i++) {
        const p = document.createElement('div');
        p.classList.add('particle');
        const size = Math.random() * 10 + 4;
        p.style.width = size + 'px';
        p.style.height = size + 'px';
        p.style.left = Math.random() * 100 + 'vw';
        p.style.animationDuration = (Math.random() * 12 + 10) + 's';
        p.style.animationDelay = (Math.random() * 10) + 's';
        particleContainer.appendChild(p);
      }
    }

    /* ---- Show / Hide Password ---- */
    const togglePassword = document.getElementById('togglePassword');
    const passwordInput = document.getElementById('password');

    if (togglePassword && passwordInput) {
      togglePassword.addEventListener('click', function () {
        const isPassword = passwordInput.getAttribute('type') === 'password';
        passwordInput.setAttribute('type', isPassword ? 'text' : 'password');
        const icon = togglePassword.querySelector('i');
        icon.classList.toggle('fa-eye');
        icon.classList.toggle('fa-eye-slash');
      });
    }

    /* ---- Restore "Remember Me" username ---- */
    const usernameInput = document.getElementById('username');
    const rememberCheckbox = document.getElementById('rememberMe');
    const savedUsername = localStorage.getItem('bnims_remember_username');

    if (savedUsername && usernameInput && rememberCheckbox) {
      usernameInput.value = savedUsername;
      rememberCheckbox.checked = true;
    }

    /* ---- Login Form Validation ---- */
    const loginForm = document.getElementById('loginForm');
    const alertBox = document.getElementById('alertBox');
    const loginBtn = document.getElementById('loginBtn');

    function showAlert(message, type) {
      alertBox.innerHTML = `<i class="fa-solid ${type === 'error' ? 'fa-circle-exclamation' : 'fa-circle-check'}"></i> ${message}`;
      alertBox.classList.remove('d-none', 'alert-error', 'alert-success');
      alertBox.classList.add(type === 'error' ? 'alert-error' : 'alert-success');

      // retrigger animation
      alertBox.style.animation = 'none';
      void alertBox.offsetWidth;
      alertBox.style.animation = '';
    }

    if (loginForm) {
      loginForm.addEventListener('submit', function (e) {
        e.preventDefault();

        const username = usernameInput.value.trim();
        const password = passwordInput.value.trim();

        // Basic required field validation
        if (!username || !password) {
          showAlert('Please fill in both Username and Password fields.', 'error');
          if (!username) usernameInput.classList.add('is-invalid-shake');
          if (!password) passwordInput.classList.add('is-invalid-shake');
          return;
        }

        // Simulate authentication loading state
        const btnText = loginBtn.querySelector('.btn-text');
        const btnLoader = loginBtn.querySelector('.btn-loader');
        btnText.classList.add('d-none');
        btnLoader.classList.remove('d-none');
        loginBtn.disabled = true;

        setTimeout(function () {
          if (username === 'admin' && password === '1234') {

            // Handle Remember Me
            if (rememberCheckbox.checked) {
              localStorage.setItem('bnims_remember_username', username);
            } else {
              localStorage.removeItem('bnims_remember_username');
            }

            // Store simple session flag
            sessionStorage.setItem('bnims_logged_in', 'true');
            sessionStorage.setItem('bnims_user', username);

            showAlert('Login successful! Redirecting to dashboard...', 'success');

            setTimeout(function () {
              window.location.href = 'dashboard.html';
            }, 900);

          } else {
            showAlert('Invalid Username or Password', 'error');
            btnText.classList.remove('d-none');
            btnLoader.classList.add('d-none');
            loginBtn.disabled = false;

            // shake the card
            const card = document.querySelector('.login-card');
            card.style.animation = 'none';
            void card.offsetWidth;
            card.style.animation = 'shakeCard 0.5s ease';
          }
        }, 1100);
      });
    }

    // Add shake keyframes dynamically (for invalid login)
    const styleTag = document.createElement('style');
    styleTag.innerHTML = `
      @keyframes shakeCard {
        0%, 100% { transform: translateX(0); }
        20% { transform: translateX(-10px); }
        40% { transform: translateX(10px); }
        60% { transform: translateX(-6px); }
        80% { transform: translateX(6px); }
      }
      .is-invalid-shake {
        border-color: var(--accent-red) !important;
        animation: shakeCard 0.4s ease;
      }
    `;
    document.head.appendChild(styleTag);

    /* ---- Send Reset Link (demo) ---- */
    const sendResetBtn = document.getElementById('sendResetBtn');
    if (sendResetBtn) {
      sendResetBtn.addEventListener('click', function () {
        sendResetBtn.innerHTML = '<i class="fa-solid fa-check"></i> Link Sent!';
        sendResetBtn.disabled = true;
        setTimeout(() => {
          const modalEl = document.getElementById('forgotModal');
          const modal = bootstrap.Modal.getInstance(modalEl);
          if (modal) modal.hide();
          sendResetBtn.innerHTML = 'Send Reset Link';
          sendResetBtn.disabled = false;
        }, 1500);
      });
    }
  }

  /* =======================================================================
     DASHBOARD PAGE LOGIC
  ======================================================================= */
  if (isDashboardPage) {

    /* ---- Simple auth guard: redirect to login if not logged in ---- */
    if (sessionStorage.getItem('bnims_logged_in') !== 'true') {
      window.location.href = 'index.html';
      return;
    }

    /* ---- Sidebar Toggle ---- */
    const sidebar = document.getElementById('sidebar');
    const sidebarToggle = document.getElementById('sidebarToggle');
    const sidebarOverlay = document.getElementById('sidebarOverlay');
    const mainContent = document.getElementById('mainContent');

    function isMobile() {
      return window.innerWidth <= 991;
    }

    if (sidebarToggle) {
      sidebarToggle.addEventListener('click', function () {
        if (isMobile()) {
          sidebar.classList.toggle('show');
          sidebarOverlay.classList.toggle('show');
        } else {
          sidebar.classList.toggle('collapsed');
          mainContent.classList.toggle('expanded');
        }
      });
    }

    if (sidebarOverlay) {
      sidebarOverlay.addEventListener('click', function () {
        sidebar.classList.remove('show');
        sidebarOverlay.classList.remove('show');
      });
    }

    /* ---- Sidebar Navigation (SPA-like section switching) ---- */
    const menuItems = document.querySelectorAll('.menu-item[data-section]');
    const sections = document.querySelectorAll('.content-section');
    const pageTitle = document.querySelector('.page-title');

    const sectionTitles = {
      'dashboard-section': '<i class="fa-solid fa-gauge-high"></i> Dashboard Overview',
      'citizens-section': '<i class="fa-solid fa-users"></i> Citizens Management',
      'add-citizen-section': '<i class="fa-solid fa-user-plus"></i> Add New Citizen',
      'verification-section': '<i class="fa-solid fa-user-check"></i> Verification Queue',
      'reports-section': '<i class="fa-solid fa-chart-column"></i> Reports & Analytics',
      'settings-section': '<i class="fa-solid fa-gear"></i> System Settings'
    };

    menuItems.forEach(item => {
      item.addEventListener('click', function (e) {
        e.preventDefault();
        const targetId = this.getAttribute('data-section');

        // update active menu item
        menuItems.forEach(mi => mi.classList.remove('active'));
        this.classList.add('active');

        // switch sections
        sections.forEach(sec => sec.classList.remove('active'));
        const targetSection = document.getElementById(targetId);
        if (targetSection) {
          targetSection.classList.add('active');
        }

        // update page title
        if (pageTitle && sectionTitles[targetId]) {
          pageTitle.innerHTML = sectionTitles[targetId];
        }

        // re-trigger counter animation when dashboard revisited
        if (targetId === 'dashboard-section') {
          animateCounters();
        }

        // close sidebar on mobile after navigation
        if (isMobile()) {
          sidebar.classList.remove('show');
          sidebarOverlay.classList.remove('show');
        }
      });
    });

    /* ---- Animated Counters for Stat Cards ---- */
    function animateCounters() {
      const counters = document.querySelectorAll('.counter');
      counters.forEach(counter => {
        const target = +counter.getAttribute('data-target');
        let current = 0;
        const increment = Math.ceil(target / 80);

        // reset before animating
        counter.textContent = '0';

        const updateCounter = () => {
          current += increment;
          if (current >= target) {
            counter.textContent = target.toLocaleString('en-US');
          } else {
            counter.textContent = current.toLocaleString('en-US');
            requestAnimationFrame(updateCounter);
          }
        };
        requestAnimationFrame(updateCounter);
      });
    }
    animateCounters();

    /* ---- Card Hover Animation Trigger (extra pop on load) ---- */
    const statCards = document.querySelectorAll('.stat-card');
    statCards.forEach((card, index) => {
      card.style.setProperty('--delay', (index * 0.1) + 's');
    });

    /* ---- Toast Notification Helper ---- */
    function showToast(message, icon = 'fa-circle-check', color = 'success') {
      const toastContainer = document.getElementById('toastContainer');
      if (!toastContainer) return;

      const toastEl = document.createElement('div');
      toastEl.className = 'toast custom-toast align-items-center border-0';
      toastEl.setAttribute('role', 'alert');
      toastEl.innerHTML = `
        <div class="d-flex">
          <div class="toast-body">
            <i class="fa-solid ${icon} text-${color} me-2"></i>${message}
          </div>
          <button type="button" class="btn-close me-2 m-auto" data-bs-dismiss="toast"></button>
        </div>
      `;
      toastContainer.appendChild(toastEl);
      const toast = new bootstrap.Toast(toastEl, { delay: 3000 });
      toast.show();

      toastEl.addEventListener('hidden.bs.toast', () => toastEl.remove());
    }

    /* ---- Add Citizen Form Submission ---- */
    const addCitizenForm = document.getElementById('addCitizenForm');
    if (addCitizenForm) {
      addCitizenForm.addEventListener('submit', function (e) {
        e.preventDefault();
        if (!addCitizenForm.checkValidity()) {
          e.stopPropagation();
          addCitizenForm.classList.add('was-validated');
          showToast('Please fill in all required fields correctly.', 'fa-triangle-exclamation', 'warning');
          return;
        }
        showToast('Citizen record has been saved successfully!', 'fa-circle-check', 'success');
        addCitizenForm.reset();
        addCitizenForm.classList.remove('was-validated');
      });
    }

    /* ---- Approve / Reject buttons (Verification Section) ---- */
    document.querySelectorAll('#verification-section .btn-success').forEach(btn => {
      btn.addEventListener('click', function () {
        const row = this.closest('tr');
        showToast('Citizen record approved and verified.', 'fa-circle-check', 'success');
        if (row) {
          row.style.transition = 'opacity 0.4s ease';
          row.style.opacity = '0';
          setTimeout(() => row.remove(), 400);
        }
      });
    });

    document.querySelectorAll('#verification-section .btn-danger').forEach(btn => {
      btn.addEventListener('click', function () {
        const row = this.closest('tr');
        showToast('Citizen application has been rejected.', 'fa-circle-xmark', 'danger');
        if (row) {
          row.style.transition = 'opacity 0.4s ease';
          row.style.opacity = '0';
          setTimeout(() => row.remove(), 400);
        }
      });
    });

    /* ---- Settings Save Button ---- */
    const settingsSaveBtn = document.querySelector('#settings-section .btn-login');
    if (settingsSaveBtn) {
      settingsSaveBtn.addEventListener('click', function () {
        showToast('Settings have been updated successfully!', 'fa-circle-check', 'success');
      });
    }

    /* ---- Report Download Buttons (demo) ---- */
    document.querySelectorAll('#reports-section .btn-outline-navy').forEach(btn => {
      btn.addEventListener('click', function () {
        showToast('Report download started (demo only).', 'fa-download', 'info');
      });
    });

    /* ---- Logout Function ---- */
    function handleLogout(e) {
      e.preventDefault();
      sessionStorage.removeItem('bnims_logged_in');
      sessionStorage.removeItem('bnims_user');
      window.location.href = 'index.html';
    }

    const logoutBtn = document.getElementById('logoutBtn');
    const logoutBtn2 = document.getElementById('logoutBtn2');
    if (logoutBtn) logoutBtn.addEventListener('click', handleLogout);
    if (logoutBtn2) logoutBtn2.addEventListener('click', handleLogout);

    /* ---- Responsive: auto-manage sidebar state on resize ---- */
    window.addEventListener('resize', function () {
      if (!isMobile()) {
        sidebar.classList.remove('show');
        sidebarOverlay.classList.remove('show');
      }
    });
  }

});
